<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="./estilo.css">
</head>
<body>

<div class="container">

    <h1>
        Bem-vinda, <?php echo $_SESSION['nome']; ?>!
    </h1>

    <p>
        Login realizado com sucesso.
    </p>

    <a href="logout.php">
        <button>Sair</button>
    </a>

</div>

</body>
</html>