<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $ra = $_POST['ra'];
    $turma = $_POST['turma'];

    $sql = "INSERT INTO usuarios(nome, email, senha, ra, turma)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Erro SQL: " . $conn->error);
    }

    $stmt->bind_param("sssis", $nome, $email, $senha, $ra, $turma);

    if ($stmt->execute()) {

        header("Location: login.php");
        exit();

    } else {

        echo "<script>alert('Erro ao criar conta!');</script>";

    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
    <link rel="stylesheet" href="./estilo.css">
</head>
<body>

<div class="container">

    <h1>Criar Conta</h1>

    <form method="POST">

        <input type="text" name="nome" placeholder="Nome" required>

        <input type="email" name="email" placeholder="Email" required>

        <input type="password" name="senha" placeholder="Senha" required>

        <input type="number" name="ra" placeholder="RA">

        <input type="text" name="turma" placeholder="Turma">

        <button type="submit">Cadastrar</button>

    </form>

    <p>
        Já possui conta?
        <a href="login.php">Entrar</a>
    </p>

</div>

</body>
</html>